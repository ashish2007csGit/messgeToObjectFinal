package com.delta.acs.btw.rtsm.rtsmhandler;

import java.io.File;
import java.io.FileNotFoundException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.test.context.junit4.SpringRunner;

import com.delta.mobility.agent.data.AgentMobilityData;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RtsmHandlerApplicationTests {
	
	AgentMobilityData agentMobilityData ;

	@Test
	public void contextLoads() {
	}
	


	@Autowired
	private JmsTemplate queueTemplate;

	private String queue = "DEV.QUEUE.1";

	@Test
	public void sendMessageToQueue() {

		queueTemplate.convertAndSend(queue, "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> \r\n" + 
				"<com.delta.mobility.agent.data.AgentMobilityData>\r\n" + 
				"  <taskCInstance>00-09-05-0001-46F056C4</taskCInstance>\r\n" + 
				"  <messageReference>\r\n" + 
				"    <timestampServer>2018-06-28 16:40:52</timestampServer>\r\n" + 
				"    <timestampUTC>2018-06-28 21:40:52</timestampUTC>\r\n" + 
				"    <station>LGA</station>\r\n" + 
				"  </messageReference>\r\n" + 
				"  <taskDetails>\r\n" + 
				"    <taskInstance>00-09-05-0001-46F056C4</taskInstance>\r\n" + 
				"    <taskName>PB/LB</taskName>\r\n" + 
				"    <deliveryFormat>Local</deliveryFormat>\r\n" + 
				"    <status>Assigned</status>\r\n" + 
				"    <resourceNumber>084813600</resourceNumber>\r\n" + 
				"    <resourceName>WILLIAMS, MALCOLM</resourceName>\r\n" + 
				"    <shiftStart>06/28/2018 12:30:00</shiftStart>\r\n" + 
				"    <shiftEnd>06/28/2018 19:00:00</shiftEnd>\r\n" + 
				"    <startPosition>BF5</startPosition>\r\n" + 
				"    <endPosition>BF5</endPosition>\r\n" + 
				"    <taskStart>06/28/2018 16:47:00</taskStart>\r\n" + 
				"    <taskEnd>06/28/2018 16:59:00</taskEnd>\r\n" + 
				"    <taskDuration>12</taskDuration>\r\n" + 
				"    <taskComment> </taskComment>\r\n" + 
				"    <taskMessageList/>\r\n" + 
				"    <flightDetails>\r\n" + 
				"      <flightInformation>\r\n" + 
				"        <flightCInstance>00-0C-02-0001-4BC8AF94</flightCInstance>\r\n" + 
				"        <carrierCode>9E</carrierCode>\r\n" + 
				"        <flightNumber>5327</flightNumber>\r\n" + 
				"        <origin>YUL</origin>\r\n" + 
				"        <destination>LGA</destination>\r\n" + 
				"        <flightDate>06/28/2018</flightDate>\r\n" + 
				"        <scheduledTime>06/28/2018 14:36:00</scheduledTime>\r\n" + 
				"        <estimatedTime>06/28/2018 16:47:00</estimatedTime>\r\n" + 
				"        <gate>BF5</gate>\r\n" + 
				"        <lockedETA></lockedETA>\r\n" + 
				"        <shipNumber>9304</shipNumber>\r\n" + 
				"        <domInt>I</domInt>\r\n" + 
				"        <flightStatus>OnGround</flightStatus>\r\n" + 
				"        <category></category>\r\n" + 
				"        <flightCbp>GT</flightCbp>\r\n" + 
				"        <preCleared>Precleared</preCleared>\r\n" + 
				"      </flightInformation>\r\n" + 
				"      <flightLoadList>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>9_BAGS</loadType>\r\n" + 
				"          <loadCount>32</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>LCL_BAGS</loadType>\r\n" + 
				"          <loadCount>18</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>LCL_BAGS</loadType>\r\n" + 
				"          <loadCount>14</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>LCL_BAGS</loadType>\r\n" + 
				"          <loadCount>7</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>LCL_BAGS_NONE</loadType>\r\n" + 
				"          <loadCount>7</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"        <com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"          <finalDestination></finalDestination>\r\n" + 
				"          <binLocation></binLocation>\r\n" + 
				"          <loadType>XFR_BAGS</loadType>\r\n" + 
				"          <loadCount>4</loadCount>\r\n" + 
				"        </com.delta.mobility.agent.data.FlightLoadData>\r\n" + 
				"      </flightLoadList>\r\n" + 
				"      <connectionList/>\r\n" + 
				"      <teamList>\r\n" + 
				"        <com.delta.mobility.agent.data.TeamData>\r\n" + 
				"          <resourceName>ABEKAN, ASHIRIFI</resourceName>\r\n" + 
				"          <resourceNumber>062018700</resourceNumber>\r\n" + 
				"          <resourceLocation>XFRPM</resourceLocation>\r\n" + 
				"          <taskName>C/D</taskName>\r\n" + 
				"        </com.delta.mobility.agent.data.TeamData>\r\n" + 
				"      </teamList>\r\n" + 
				"    </flightDetails>\r\n" + 
				"  </taskDetails>\r\n" + 
				"</com.delta.mobility.agent.data.AgentMobilityData>\r\n" + 
				"");
	}

	@Test
	public void receiveMessageFromQueue() {

		queueTemplate.receiveAndConvert(queue);
	}

	@Test
	public void sendMessageToQueueWithSelector() {

		queueTemplate.convertAndSend(queue, "hello world", (MessagePostProcessor) (message) -> {
			{
				message.setStringProperty("name", "test");
				return message;
			}
		});
	}

	@Test
	public void receiveMessageFromQueueWithSelector() {

		queueTemplate.receiveSelected(queue, "name='tony'");
	}


	/*@Test
    public void testObjectToXml() throws JAXBException, FileNotFoundException {
		File file = new File("message.xml");
        JAXBContext jaxbContext = JAXBContext.newInstance(AgentMobilityData.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        agentMobilityData = (AgentMobilityData) unmarshaller.unmarshal(file);
        System.out.println(agentMobilityData);
    }*/

}
