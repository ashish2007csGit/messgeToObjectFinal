package com.delta.acs.btw.rtsm.rtsmhandler.config;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.delta.mobility.agent.data.AgentMobilityData;

/**
 * Ashish Mishra
 */
public class Util {
	static AgentMobilityData agentMobilityData ;

	public static AgentMobilityData toObject(String xmlMessage) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(AgentMobilityData.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		StringReader reader = new StringReader(xmlMessage);
		agentMobilityData = (AgentMobilityData) unmarshaller.unmarshal(reader);

		return agentMobilityData;

	}

}
