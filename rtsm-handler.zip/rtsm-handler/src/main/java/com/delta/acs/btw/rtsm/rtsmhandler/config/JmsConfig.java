package com.delta.acs.btw.rtsm.rtsmhandler.config;

import javax.jms.MessageListener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.SimpleMessageListenerContainer;
import org.springframework.messaging.converter.MarshallingMessageConverter;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.delta.acs.btw.rtsm.rtsmhandler.listner.MQListener;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

@Configuration
public class JmsConfig {
	
	@Value("${servers.mq.host}")
	private String host;
	@Value("${servers.mq.port}")
	private Integer port;
	@Value("${servers.mq.queue-manager}")
	private String queueManager;
	@Value("${servers.mq.channel}")
	private String channel;
	@Value("${servers.mq.queue}")
	private String queue;
	@Value("${servers.mq.timeout}")
	private long timeout;
	
	@Bean
	@Primary
	public MQQueueConnectionFactory mqQueueConnectionFactory() {
		System.out.println("mqQueueConnectionFactory");
		MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
		try {	
			mqQueueConnectionFactory.setHostName(host);
			mqQueueConnectionFactory.setQueueManager(queueManager);
			mqQueueConnectionFactory.setPort(port);
			mqQueueConnectionFactory.setChannel(channel);
			mqQueueConnectionFactory.setAppName(System.getProperty("user.name"));
			mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			mqQueueConnectionFactory.setCCSID(1208);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Done mqQueueConnectionFactory");
		return mqQueueConnectionFactory;
	}
	
	@Bean
	public SimpleMessageListenerContainer queueContainer(MQQueueConnectionFactory mqQueueConnectionFactory) {
		MessageListener listener = new MQListener();
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(mqQueueConnectionFactory);
		container.setDestinationName(queue);
		container.setMessageListener(listener);
		container.start();
		return container;
	}	
	
	@Bean
	public JmsTemplate queueTemplate(MQQueueConnectionFactory mqQueueConnectionFactory) {
		System.out.println("queueTemplate");
		JmsTemplate jmsTemplate = new JmsTemplate(mqQueueConnectionFactory);
		jmsTemplate.setReceiveTimeout(timeout);
		System.out.println("Done queueTemplate");
		return jmsTemplate;
	}
	/*
	@Bean
	MessageConverter messageConverter() {
	    MarshallingMessageConverter converter = new MarshallingMessageConverter();
	    // set this converter on the implicit Spring JMS template
	    jmsTemplate.messageConverter = converter
	    converter
	}

	@Bean
	Jaxb2Marshaller marshaller() {
	    Jaxb2Marshaller marshaller = new Jaxb2Marshaller()
	    marshaller.classesToBeBound = [My.class, MyOther.class]
	    marshaller
	}*/
	
}
