package com.delta.acs.btw.rtsm.rtsmhandler.listner;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.xml.bind.JAXBException;

import org.springframework.stereotype.Component;

import com.delta.acs.btw.rtsm.rtsmhandler.config.Util;
import com.delta.mobility.agent.data.AgentMobilityData;

@Component
public class MQListener implements MessageListener {

	@Override
	public void onMessage(Message message) {
		try {
			System.out.println("message received:" + message.getBody(String.class));
			AgentMobilityData agentMobilityData = Util.toObject(message.getBody(String.class));
			System.out.println(" XML message after conversion  "+ agentMobilityData.toString());
		} catch (JMSException | JAXBException e) {
			e.printStackTrace();
		}

	}
}