package com.delta.mobility.agent.data;

/**
 * Ashish Mishra
 */
public class TeamData {
	private String resourceNumber;

	private String resourceLocation;

	private String taskName;

	private String resourceName;

	public String getResourceNumber() {
		return resourceNumber;
	}

	public void setResourceNumber(String resourceNumber) {
		this.resourceNumber = resourceNumber;
	}

	public String getResourceLocation() {
		return resourceLocation;
	}

	public void setResourceLocation(String resourceLocation) {
		this.resourceLocation = resourceLocation;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	@Override
	public String toString() {
		return "TeamData [resourceNumber = " + resourceNumber + ", resourceLocation = " + resourceLocation
				+ ", taskName = " + taskName + ", resourceName = " + resourceName + "]";
	}

}
