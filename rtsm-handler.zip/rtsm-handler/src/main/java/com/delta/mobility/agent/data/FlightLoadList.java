package com.delta.mobility.agent.data;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlElement;

public class FlightLoadList
{
	
    private com.delta.mobility.agent.data.FlightLoadData[] fileLoadData;

    @XmlElement(name = "com.delta.mobility.agent.data.FlightLoadData")
	public com.delta.mobility.agent.data.FlightLoadData[] getFileLoadData() {
		return fileLoadData;
	}

	public void setFileLoadData(com.delta.mobility.agent.data.FlightLoadData[] fileLoadData) {
		this.fileLoadData = fileLoadData;
	}

	@Override
	public String toString() {
		return "FlightLoadList [fileLoadData=" + Arrays.toString(fileLoadData) + "]";
	}

   
}