package com.delta.mobility.agent.data;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Ashish Mishra  
 */
@XmlRootElement(name="com.delta.mobility.agent.data.AgentMobilityData")
public class AgentMobilityData {

	
    private MessageReference messageReference;

	
    private TaskDetails taskDetails;

    private String taskCInstance;

	@XmlElement(name = "messageReference")
    public MessageReference getMessageReference ()
    {
        return messageReference;
    }

    public void setMessageReference (MessageReference messageReference)
    {
        this.messageReference = messageReference;
    }

    @XmlElement
    public TaskDetails getTaskDetails ()
    {
        return taskDetails;
    }

    public void setTaskDetails (TaskDetails taskDetails)
    {
        this.taskDetails = taskDetails;
    }

    public String getTaskCInstance ()
    {
        return taskCInstance;
    }

    public void setTaskCInstance (String taskCInstance)
    {
        this.taskCInstance = taskCInstance;
    }

    @Override
    public String toString()
    {
        return "AgentMobilityData [messageReference = "+messageReference+", taskDetails = "+taskDetails+", taskCInstance = "+taskCInstance+"]";
    }
}