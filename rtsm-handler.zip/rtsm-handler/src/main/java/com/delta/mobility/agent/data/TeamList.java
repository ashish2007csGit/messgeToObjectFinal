package com.delta.mobility.agent.data;

import javax.xml.bind.annotation.XmlElement;

public class TeamList {
	private com.delta.mobility.agent.data.TeamData teamData;

	
	@XmlElement(name = "com.delta.mobility.agent.data.TeamData")
	public com.delta.mobility.agent.data.TeamData getTeamData() {
		return teamData;
	}

	public void setTeamData(com.delta.mobility.agent.data.TeamData teamData) {
		this.teamData = teamData;
	}

	@Override
	public String toString() {
		return "TeamList [com.delta.mobility.agent.data.TeamData = " + teamData + "]";
	}
}