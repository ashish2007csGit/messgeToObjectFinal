package com.delta.mobility.agent.data;

/**
 * Ashish Mishra
 */
public class TaskDetails {

	private String shiftStart;

	private String deliveryFormat;

	private String status;

	private String taskName;

	private String taskDuration;

	private String shiftEnd;

	private String resourceNumber;

	private String taskStart;

	private String taskMessageList;

	private String taskEnd;

	private String taskComment;

	private String endPosition;

	private String resourceName;

	private String startPosition;

	private String taskInstance;

	private FlightDetails flightDetails;

	public String getShiftStart() {
		return shiftStart;
	}

	public void setShiftStart(String shiftStart) {
		this.shiftStart = shiftStart;
	}

	public String getDeliveryFormat() {
		return deliveryFormat;
	}

	public void setDeliveryFormat(String deliveryFormat) {
		this.deliveryFormat = deliveryFormat;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDuration() {
		return taskDuration;
	}

	public void setTaskDuration(String taskDuration) {
		this.taskDuration = taskDuration;
	}

	public String getShiftEnd() {
		return shiftEnd;
	}

	public void setShiftEnd(String shiftEnd) {
		this.shiftEnd = shiftEnd;
	}

	public String getResourceNumber() {
		return resourceNumber;
	}

	public void setResourceNumber(String resourceNumber) {
		this.resourceNumber = resourceNumber;
	}

	public String getTaskStart() {
		return taskStart;
	}

	public void setTaskStart(String taskStart) {
		this.taskStart = taskStart;
	}

	public String getTaskMessageList() {
		return taskMessageList;
	}

	public void setTaskMessageList(String taskMessageList) {
		this.taskMessageList = taskMessageList;
	}

	public String getTaskEnd() {
		return taskEnd;
	}

	public void setTaskEnd(String taskEnd) {
		this.taskEnd = taskEnd;
	}

	public String getTaskComment() {
		return taskComment;
	}

	public void setTaskComment(String taskComment) {
		this.taskComment = taskComment;
	}

	public String getEndPosition() {
		return endPosition;
	}

	public void setEndPosition(String endPosition) {
		this.endPosition = endPosition;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getStartPosition() {
		return startPosition;
	}

	public void setStartPosition(String startPosition) {
		this.startPosition = startPosition;
	}

	public String getTaskInstance() {
		return taskInstance;
	}

	public void setTaskInstance(String taskInstance) {
		this.taskInstance = taskInstance;
	}

	public FlightDetails getFlightDetails() {
		return flightDetails;
	}

	public void setFlightDetails(FlightDetails flightDetails) {
		this.flightDetails = flightDetails;
	}

	@Override
	public String toString() {
		return "TaskDetails [shiftStart = " + shiftStart + ", deliveryFormat = " + deliveryFormat + ", status = " + status
				+ ", taskName = " + taskName + ", taskDuration = " + taskDuration + ", shiftEnd = " + shiftEnd
				+ ", resourceNumber = " + resourceNumber + ", taskStart = " + taskStart + ", taskMessageList = "
				+ taskMessageList + ", taskEnd = " + taskEnd + ", taskComment = " + taskComment + ", endPosition = "
				+ endPosition + ", resourceName = " + resourceName + ", startPosition = " + startPosition
				+ ", taskInstance = " + taskInstance + ", flightDetails = " + flightDetails + "]";
	}
}
