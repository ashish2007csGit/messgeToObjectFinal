package com.delta.mobility.agent.data;

public class RtsmMessageObject
{
    private com.delta.mobility.agent.data.AgentMobilityData agentMobilityData;

   

    public com.delta.mobility.agent.data.AgentMobilityData getAgentMobilityData() {
		return agentMobilityData;
	}



	public void setAgentMobilityData(com.delta.mobility.agent.data.AgentMobilityData agentMobilityData) {
		this.agentMobilityData = agentMobilityData;
	}



	@Override
    public String toString()
    {
        return "RtsmMessageObject [agentMobilityData = "+agentMobilityData+"]";
    }
}
		