package com.delta.mobility.agent.data;

/**
 * Ashish Mishra  
 */
public class FlightInformation {
	private String origin;

    private String flightNumber;

    private String flightStatus;

    private String carrierCode;

    private String shipNumber;

    private String preCleared;

    private String destination;

    private String gate;

    private String estimatedTime;

    private String category;

    private String flightCInstance;

    private String lockedETA;

    private String flightDate;

    private String scheduledTime;

    private String domInt;

    private String flightCbp;

    public String getOrigin ()
    {
        return origin;
    }

    public void setOrigin (String origin)
    {
        this.origin = origin;
    }

    public String getFlightNumber ()
    {
        return flightNumber;
    }

    public void setFlightNumber (String flightNumber)
    {
        this.flightNumber = flightNumber;
    }

    public String getFlightStatus ()
    {
        return flightStatus;
    }

    public void setFlightStatus (String flightStatus)
    {
        this.flightStatus = flightStatus;
    }

    public String getCarrierCode ()
    {
        return carrierCode;
    }

    public void setCarrierCode (String carrierCode)
    {
        this.carrierCode = carrierCode;
    }

    public String getShipNumber ()
    {
        return shipNumber;
    }

    public void setShipNumber (String shipNumber)
    {
        this.shipNumber = shipNumber;
    }

    public String getPreCleared ()
    {
        return preCleared;
    }

    public void setPreCleared (String preCleared)
    {
        this.preCleared = preCleared;
    }

    public String getDestination ()
    {
        return destination;
    }

    public void setDestination (String destination)
    {
        this.destination = destination;
    }

    public String getGate ()
    {
        return gate;
    }

    public void setGate (String gate)
    {
        this.gate = gate;
    }

    public String getEstimatedTime ()
    {
        return estimatedTime;
    }

    public void setEstimatedTime (String estimatedTime)
    {
        this.estimatedTime = estimatedTime;
    }

    public String getCategory ()
    {
        return category;
    }

    public void setCategory (String category)
    {
        this.category = category;
    }

    public String getFlightCInstance ()
    {
        return flightCInstance;
    }

    public void setFlightCInstance (String flightCInstance)
    {
        this.flightCInstance = flightCInstance;
    }

    public String getLockedETA ()
    {
        return lockedETA;
    }

    public void setLockedETA (String lockedETA)
    {
        this.lockedETA = lockedETA;
    }

    public String getFlightDate ()
    {
        return flightDate;
    }

    public void setFlightDate (String flightDate)
    {
        this.flightDate = flightDate;
    }

    public String getScheduledTime ()
    {
        return scheduledTime;
    }

    public void setScheduledTime (String scheduledTime)
    {
        this.scheduledTime = scheduledTime;
    }

    public String getDomInt ()
    {
        return domInt;
    }

    public void setDomInt (String domInt)
    {
        this.domInt = domInt;
    }

    public String getFlightCbp ()
    {
        return flightCbp;
    }

    public void setFlightCbp (String flightCbp)
    {
        this.flightCbp = flightCbp;
    }

    @Override
    public String toString()
    {
        return "FlightInformation [origin = "+origin+", flightNumber = "+flightNumber+", flightStatus = "+flightStatus+", carrierCode = "+carrierCode+", shipNumber = "+shipNumber+", preCleared = "+preCleared+", destination = "+destination+", gate = "+gate+", estimatedTime = "+estimatedTime+", category = "+category+", flightCInstance = "+flightCInstance+", lockedETA = "+lockedETA+", flightDate = "+flightDate+", scheduledTime = "+scheduledTime+", domInt = "+domInt+", flightCbp = "+flightCbp+"]";
    }

}
