package com.delta.mobility.agent.data;

public class FlightDetails {

	private FlightLoadList flightLoadList;
	
	private String connectionList;

	private FlightInformation flightInformation;

	private TeamList teamList;

	public FlightLoadList getFlightLoadList() {
		return flightLoadList;
	}

	public void setFlightLoadList(FlightLoadList flightLoadList) {
		this.flightLoadList = flightLoadList;
	}

	public String getConnectionList() {
		return connectionList;
	}

	public void setConnectionList(String connectionList) {
		this.connectionList = connectionList;
	}

	public FlightInformation getFlightInformation() {
		return flightInformation;
	}

	public void setFlightInformation(FlightInformation flightInformation) {
		this.flightInformation = flightInformation;
	}

	public TeamList getTeamList() {
		return teamList;
	}

	public void setTeamList(TeamList teamList) {
		this.teamList = teamList;
	}

	@Override
	public String toString() {
		return "FlightDetails [flightLoadList = " + flightLoadList + ", connectionList = " + connectionList
				+ ", flightInformation = " + flightInformation + ", teamList = " + teamList + "]";
	}

}
