package com.delta.mobility.agent.data;

/**
 * Ashish Mishra  
 */
public class FlightLoadData { 

private String loadType;

private String binLocation;

private String finalDestination;

private String loadCount;

public String getLoadType ()
{
    return loadType;
}

public void setLoadType (String loadType)
{
    this.loadType = loadType;
}

public String getBinLocation ()
{
    return binLocation;
}

public void setBinLocation (String binLocation)
{
    this.binLocation = binLocation;
}

public String getFinalDestination ()
{
    return finalDestination;
}

public void setFinalDestination (String finalDestination)
{
    this.finalDestination = finalDestination;
}

public String getLoadCount ()
{
    return loadCount;
}

public void setLoadCount (String loadCount)
{
    this.loadCount = loadCount;
}

@Override
public String toString()
{
    return "FlightLoadData [loadType = "+loadType+", binLocation = "+binLocation+", finalDestination = "+finalDestination+", loadCount = "+loadCount+"]";
}}
