package com.delta.mobility.agent.data;

/**
 * Ashish Mishra  
 */
public class MessageReference {
	private String station;

    private String timestampServer;

    private String timestampUTC;

    public String getStation ()
    {
        return station;
    }

    public void setStation (String station)
    {
        this.station = station;
    }

    public String getTimestampServer ()
    {
        return timestampServer;
    }

    public void setTimestampServer (String timestampServer)
    {
        this.timestampServer = timestampServer;
    }

    public String getTimestampUTC ()
    {
        return timestampUTC;
    }

    public void setTimestampUTC (String timestampUTC)
    {
        this.timestampUTC = timestampUTC;
    }

    @Override
    public String toString()
    {
        return "MessageReference [station = "+station+", timestampServer = "+timestampServer+", timestampUTC = "+timestampUTC+"]";
    }

}
